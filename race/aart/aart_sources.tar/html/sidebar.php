	<div class="flakes-frame">

		<div class="flakes-navigation">
			<a href="index.php" class="logo">
				<h1>AArt</h1>
			</a>

			<ul>
				<li class="title">Navigation</li>
				<li><a href="index.php">Home</a></li>
				<li><a href="register.php">Register</a></li>
				<li><a href="login.php">Login</a></li>
				<li><a href="submit.php">Submit</a></li>
			</ul>

		</div>
