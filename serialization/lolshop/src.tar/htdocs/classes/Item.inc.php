<?php

class Item {

    private $product;
    private $quantity;

    function getProduct() {
        return $this->product;
    }

    function getQuantity() {
        return $this->quantity;
    }

}
?>
